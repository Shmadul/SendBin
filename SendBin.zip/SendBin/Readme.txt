SendBin: 
Created by: @shmadul 2018

Requirements:
Python 3.x
Homebrew
pyusb
MacOS

NOTICE:
I'm not claiming to have made fusée gelée, or trying to take any credit for ktemkin's work,
I just made this script for myself and figured others might find it useful, if you have any 
issues, you can dm me on twitter (@shmadul)

Credits:
ktemkin		   -- fusée gelée 
SciresM, motezazer -- guidance and support 
hedgeberg, andeor  -- dumping the Jetson bootROM
TuxSH              -- for IDB notes that were super nice to peek at
sveinbjornt	   —- Platypus
shmadul		   -- SendBin